module.exports = [
    "SOCIETYCOIN","SOCIETY"
  ];